<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('titulo', 'Error'); ?> · M&amp;A Computers</title>
    <link rel="icon" href="<?php echo e(asset('images/logo-mark.jpg')); ?>">
    <script>
        (function () {
            var t = localStorage.getItem('tema');
            if (t === 'oscuro' || (!t && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
                document.documentElement.classList.add('dark');
            }
        })();
    </script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="flex min-h-screen flex-col items-center justify-center bg-canvas px-4 font-sans text-ink">
    <a href="<?php echo e(auth()->check() ? route('inicio') : route('login')); ?>" class="mb-8">
        <img src="<?php echo e(asset('images/logo.jpg')); ?>" alt="M&amp;A Computers" class="h-14 rounded-lg object-contain">
    </a>
    <?php echo $__env->yieldContent('contenido'); ?>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/layouts/blank.blade.php ENDPATH**/ ?>