<?php

use App\Http\Middleware\CabecerasSeguridad;
use App\Http\Middleware\EnsurePermiso;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        // Caddy termina TLS y envía X-Forwarded-Proto; así los assets salen como https.
        $middleware->trustProxies(at: '*');

        $middleware->append(CabecerasSeguridad::class);

        $middleware->alias([
            'permiso' => EnsurePermiso::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(
            fn (Request $request) => $request->is('api/*') || $request->expectsJson(),
        );
    })->create();
